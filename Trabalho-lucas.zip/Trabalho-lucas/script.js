// Mostrar botão de rolar para o topo ao rolar
window.onscroll = function() {
    const scrollTopButton = document.getElementById("scroll-top");
    if (document.documentElement.scrollTop > 100) {
        scrollTopButton.style.display = "block";
    } else {
        scrollTopButton.style.display = "none";
    }
};

// Função para rolar para o topo da página
function scrollToTop() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
}
